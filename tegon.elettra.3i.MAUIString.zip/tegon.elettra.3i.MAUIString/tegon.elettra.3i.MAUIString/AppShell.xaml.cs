﻿namespace tegon.elettra._3i.MAUIString;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
