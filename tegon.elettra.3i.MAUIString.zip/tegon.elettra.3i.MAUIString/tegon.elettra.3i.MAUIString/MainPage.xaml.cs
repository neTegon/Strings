﻿namespace tegon.elettra._3i.MAUIString;

public partial class MainPage : ContentPage
{

	public MainPage()
	{
		InitializeComponent();
	}
    int Lunghezza(string comecavolomipare)
	{
		char[] caratteri = comecavolomipare.ToCharArray();
		int retVal =0;
		foreach(var carattere in caratteri) 
		{ 
			retVal++;
		}
		return retVal;
	}
	bool isletter(char c)
	{
        if (c >= 'a' && c <= 'z')
        {
			return true;
        }
        if (c >= 'A' && c <= 'Z')
        {
            return true;
        }
        return false;
    }
    bool isdigit(char c)
    {
        if (c >= '0' && c <= '9')
        {
            return true;
        }
        return false;
    }
	bool alfanumerico( string s )
	{
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
        for (int idx = 0; idx < len; idx++)
        {
            if (isletter(caratteri[idx]) || isdigit(caratteri[idx]))
            {
                
            }
			else
			{
				return false;
			}
        }
		return true;
    }
    bool alfabetico(string s)
    {
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
        for (int idx = 0; idx < len; idx++)
        {
            if (isletter(caratteri[idx]))
            {

            }
            else
            {
                return false;
            }
        }
        return true;
    }
    int nlettere(string s)
	{
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
		int n = 0;
        for (int idx = 0; idx < len; idx++)
        {
            if (isletter(caratteri[idx]))
            {
				n = n + 1;
            }
        }
        return n;
    }
    string Maiuscolo(string s)
    {
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
        for (int idx = 0; idx < len; idx++)
        {
            if (caratteri[idx] >= 'a' || caratteri[idx] <= 'z')
            {
                int a = (int)caratteri[idx] & 0x5f;
                caratteri[idx] = (char)a;
            }
        }
        return new String(caratteri);
    }
    string Minuscolo(string s)
    {
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
        for (int idx = 0; idx < len; idx++)
        {

            if (caratteri[idx] >= 'a' || caratteri[idx] <= 'z')
            {
                int a = (int)caratteri[idx] | 0x20;
                caratteri[idx] = (char)a;
            }
        }
        return new String(caratteri);
    }
    string Capitalizzata(string s)
    {
        int len = Lunghezza(s);
        s=Minuscolo(s);
        char[] caratteri = s.ToCharArray();
        caratteri[0] = Maiuscolo(caratteri[0].ToString()).ToCharArray()[0];
        for (int idx = 1; idx < len; idx++)
            if (caratteri[idx] == ' ')
                caratteri[idx + 1] = Maiuscolo(caratteri[idx + 1].ToString()).ToCharArray()[0];
        return new string (caratteri);
    }

    string Reverse(string s)
    {
        int len = Lunghezza(s) - 1;
        char[] caratteri = s.ToCharArray();
        char tmp;
        for (int idx = 0; idx < len; idx++)
        {
            tmp = caratteri[idx];
            caratteri[idx] = caratteri[len];
            caratteri[len] = tmp;
            len--;
        }
        return new String(caratteri);
    }

    string nospace(string s)
    {
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
        for (int idx = 0; idx < len; idx++)
        {
            if (caratteri[idx] == ' ')
            {
                for (int j = idx; j < len; j++)
                {
                    caratteri[j] = caratteri[j + 1];
                }
            }
        }
        return new string (caratteri);
    }
    bool palindromo(string s)
    {
        int len = Lunghezza(s);
        char[] caratteri = s.ToCharArray();
        if (alfabetico(s) == false)
        {
            return false;
        }
        for (int idx = 0; idx < len; idx++)
        {
            caratteri[idx] = Minuscolo(caratteri[idx].ToString()).ToCharArray()[idx];
            caratteri[idx] = nospace(caratteri[idx].ToString()).ToCharArray()[idx];
        }
        if (new string(caratteri) == Reverse(new string (caratteri)))
        {
            return true;
        }
        return false;
    }
    int numparole(string s)
    {
        int len = Lunghezza(s);
        int n=1;
        char[] caratteri = s.ToCharArray();
        for (int idx = 0; idx < len; idx++)
        {
            if (caratteri[idx] == ' ' && isletter(caratteri[idx + 1]))
            {
                n++;
            }
        }
        return n;
    }
    
	private void OnCounterClicked(object sender, EventArgs e)
	{
		txtMaiuscola.Text = Maiuscolo(edtTesto.Text);
		txtMinuscola.Text = Minuscolo(edtTesto.Text);
        txtnlettere.Text = nlettere(edtTesto.Text).ToString();
        txtalfanumerici.Text = alfanumerico(edtTesto.Text).ToString();
        txtalfabetico.Text = alfabetico(edtTesto.Text).ToString();
        txtReverse.Text = Reverse(edtTesto.Text);
        txtCapitalizzata.Text = Capitalizzata(edtTesto.Text).ToString();
        txtnparole.Text=numparole(edtTesto.Text).ToString();
        txtpalindroma.Text=palindromo(edtTesto.Text).ToString();
        txtCapitalizzata.Text=Capitalizzata(edtTesto.Text).ToString();
        SemanticScreenReader.Announce(CounterBtn.Text);
    }

}