﻿namespace tegon.elettra._3i.MAUIString;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}
}
